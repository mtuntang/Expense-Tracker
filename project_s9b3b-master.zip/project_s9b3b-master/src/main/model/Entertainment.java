package model;

public class Entertainment extends Expense {

    public Entertainment(double amount, String descr) {
        super(amount, descr);
    }

}
