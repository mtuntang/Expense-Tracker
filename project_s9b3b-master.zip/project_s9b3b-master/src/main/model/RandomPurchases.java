package model;

public class RandomPurchases extends Entertainment {

    public RandomPurchases(double amount, String desc) {
        super(amount, desc);
    }
}
